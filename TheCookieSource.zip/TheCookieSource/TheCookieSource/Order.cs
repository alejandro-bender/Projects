﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheCookieSource
{
    [Serializable]
   public class Order : IComparable
    {
        public string oName { get; set; }
        public long oNumber { get; set; }
        public double oQuantity { get; set; }
        public string Rtype { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }

        
        public Order()
        {
            oName = "";
            oNumber = 0000000000;
            oQuantity = 0;
            Rtype = "Sugar";
        }


        public Order(string name, long number, double quantity, string type, DateTime DeliveryDate, DateTime OrderDate)
        {
            oName = name;
            oNumber = number;
            oQuantity = quantity;
            Rtype = type;
            DeliveryDate = DateTime.Today;
            OrderDate = DateTime.Today;
        }

        public override string ToString()
        {
            return "Your name is: " + oName + "\n" + 
                "Your phone number is: " + oNumber + "\n" + 
                "What kind of cookie: " + Rtype + "\n" + 
                "How many cookies:  " + oQuantity + "\n" + 
                "Your order date is " + OrderDate + "\n" +
                "Your delivery date" + DeliveryDate + "\n";
        }

        int IComparable.CompareTo(object o)
        {
            int returnVal;
            Order temp = (Order)o;
            if (this.DeliveryDate > temp.DeliveryDate)
                returnVal = 1;
            else
                if (this.DeliveryDate < temp.DeliveryDate)
                returnVal = -1;
            else
                returnVal = 0;
            return returnVal;
        }
    }
}
