﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace TheCookieSource
{

    public partial class CMenu : Form
    {
       public static List<Order> OrderList = new List<Order>();

        public CMenu()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you wish write these books to the file",
                "Write To File", MessageBoxButtons.YesNo, MessageBoxIcon.Hand,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                try
                {
                    FileStream outFile = new FileStream("booklist.ser",
                         FileMode.Create, FileAccess.Write);
                    BinaryFormatter bf = new BinaryFormatter();

                    foreach (var item in OrderList)
                    {
                        bf.Serialize(outFile, item);
                    }
                    outFile.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error writing list to file " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("New items not written");
            }
            Environment.Exit(0);
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            this.Hide();
            Display dForm = new Display();
            dForm.ShowDialog();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            this.Hide();
            Input dForm = new Input();
            dForm.ShowDialog();
        }

        private void CMenu_Load(object sender, EventArgs e)
        {

        }
    }
}
