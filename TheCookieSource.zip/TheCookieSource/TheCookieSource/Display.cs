﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheCookieSource
{
    public partial class Display : Form
    {
        public Display()
        {
            InitializeComponent();
        }

        private void Display_Load(object sender, EventArgs e)
        {
            
            List<Order> sortedOrders = new List<Order>(CMenu.OrderList);
            sortedOrders.Sort();

            foreach (var item in sortedOrders)
            {
                if (item != null)
                {
                    lblDisplay.Text += item.ToString();
                    lblDisplay.Text += "\n";

                }

            }
            sortedOrders.Clear();
        }

        private void btnBck_Click(object sender, EventArgs e)
        {
            this.Hide();
            CMenu dForm = new CMenu();
            dForm.ShowDialog();
        }

        private void btnPlace_Click(object sender, EventArgs e)
        {
            this.Hide();
            Input dForm = new Input();
            dForm.ShowDialog();
        }
    }
}
