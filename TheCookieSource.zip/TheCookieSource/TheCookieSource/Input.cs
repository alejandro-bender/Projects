﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace TheCookieSource
{
    public partial class Input : Form
    {
        
        public Input()
        {
            InitializeComponent();
        }

        private void btnBck_Click(object sender, EventArgs e)
        {
            this.Hide();
            CMenu dForm = new CMenu();
            dForm.ShowDialog();
        }

        private void btnPlace_Click(object sender, EventArgs e)
        {

            //get each field and validate before instantiating
            Order o = new Order();


            if (String.IsNullOrEmpty(txtName.Text.Trim()))
            {
                o.oName = null;
                MessageBox.Show("This is not a correct name. Please try again");
                return;
            }
            else
            {
                o.oName = txtName.Text;
            }

            try
            {
                if (txtNumber.Text.Length != 10)
                {
                    MessageBox.Show("The number needs to be 10 digits long");
                }
                o.oNumber = Convert.ToInt64(txtNumber.Text); 
            }
            catch (Exception)
            {
                MessageBox.Show("This is not correct number. Please try again");
                return;
            }

            try
            {
                if (txtQuat.Text.Length < 0 || txtQuat.Text.Length > 99)
                {
                    MessageBox.Show("The Quantity is between 1 and 99");
                }
                else
                {
                    o.oQuantity = Convert.ToDouble(txtQuat.Text);
                }
               
            }
            catch (Exception)
            {
                MessageBox.Show("This is not correct quantity it must be number no letters. Please try again");
                return;
            }
            //o.Rtype = "";
            o.OrderDate = DateTime.Today;
            o.DeliveryDate = dateTimePicker1.Value;

            //if (radioButton1 2 and 3 == false)
            //{
            //    MessageBox.Show("You need to pick one of the buttons");
            //}

            CMenu.OrderList.Add(o);
            txtName.Clear();
            txtNumber.Clear();
            txtQuat.Clear();
            this.Hide();
            Display dForm = new Display();
            dForm.ShowDialog();
        }

        private void Input_Load(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Today.AddDays(1);
          

            try
            {
                if (File.Exists("booklist.ser"))
                {
                    FileStream inFile = new FileStream("booklist.ser",
                        FileMode.Open, FileAccess.Read);
                    BinaryFormatter bFormatter = new BinaryFormatter();

                    //copy invoices from the file to the invoiceList
                    while (inFile.Position < inFile.Length)
                    {
                        /* use this logic if only a single object type is in the file                        
                        Book book = (Book)bFormatter.Deserialize(inFile);
                        Form1.bookList.Add(book);                        
                        */
                        //use this logic if multiple object types are in the file
                        object obj = bFormatter.Deserialize(inFile);
                        if (obj.GetType() == typeof(Order))
                        {
                            CMenu.OrderList.Add((Order)obj);
                        }
                        else
                        {
                            //additional logic if other types of objects are involved
                        }
                    }
                    inFile.Close();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening file, program terminating" + ex.Message);
            }
        }

        public string bb;
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                bb = "Chocolate Chip";
                return;
            }
            else if (radioButton2.Checked == true)
            {
                bb = "Oatmeal";
                return;
            }
            else if (radioButton3.Checked == true)
            {
                bb = "Sugar";
                return;
            }  
        }
    }
}
