﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaroldHomeServices
{
    public class Job : IComparable
    {
        public string Jobdesc { get; set; }
        public double Hrcomplete { get; set; }
        public double Hrrate { get; set; }


        public Job(string desc)
        {
            Jobdesc = desc;
            Hrcomplete = 1;
            Hrrate = 10.00;
        }

        public Job()
        {
            Jobdesc = "Clean the house";
            Hrcomplete = 6;
            Hrrate = 2.50;
        }

        public Job(string jdesc, double jHrcomplete, double jHrrate)
        {
            Jobdesc = jdesc;
            Hrcomplete = jHrcomplete;
            Hrrate = jHrrate;
        }

        public double Fee()
        {
            return Hrcomplete * Hrrate;
        }

        public override string ToString()
        {
            return "Your job description is: " + Jobdesc +"\n" +"Your Hours to complete the job is: " + Hrcomplete.ToString("F2") + "\n" + "Your rate is: " + Hrrate.ToString("C") + "\n" + "Your total amount is:  " + Fee().ToString("C") + "\n";
        }

        int IComparable.CompareTo(object o)
        {
            int returnVal;
            Job temp = (Job)o;
            if (this.Fee() > temp.Fee())
                returnVal = 1;
            else
                if (this.Fee() < temp.Fee())
                returnVal = -1;
            else
                returnVal = 0;
            return returnVal;
        }

        public static Job operator +(Job first, Job second)
        {
            string newJobDesc = first.Jobdesc + " and " + second.Jobdesc;
            double newHrcomplete = first.Hrcomplete + second.Hrcomplete;
            double newHrrate = (first.Hrrate + second.Hrrate) / 2;
            double newFee = newHrrate * newHrcomplete;
            return (new Job(newJobDesc, newHrcomplete, newHrrate));
        }
    }
}
