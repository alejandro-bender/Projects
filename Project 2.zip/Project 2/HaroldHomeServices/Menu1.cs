﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HaroldHomeServices
{
    public partial class Menu1 : Form
    {
        public static Job[] jArray = new Job[5];
        public static int jIndex = 0;

        public Menu1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 dForm = new Form1();
            dForm.ShowDialog();
        }


        private void btnDemo_Click(object sender, EventArgs e)
        {
            this.Hide();
            Demo dForm = new Demo();
            dForm.ShowDialog();
        }

        private void Menu1_Load(object sender, EventArgs e)
        {
            btnDisplay.Enabled = false;

            if (Menu1.jIndex > 4)
            {
                btnDisplay.Enabled = true;
                lblMenu1.Text = "Ok now u can click";
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            this.Hide();
            InputData dForm = new InputData();
            dForm.ShowDialog();
        }
    }
}
