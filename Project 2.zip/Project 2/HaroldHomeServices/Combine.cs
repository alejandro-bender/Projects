﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HaroldHomeServices
{
    public partial class Combine : Form
    {
        public Combine()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu1 dForm = new Menu1();
            dForm.ShowDialog();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Job Job3 = Menu1.jArray[comboBox1.SelectedIndex] + Menu1.jArray[comboBox2.SelectedIndex];
            lblcombine.Text = Job3.ToString();
        }

      
    }
}
