﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaroldHomeServices
{
    class Items
    {
        public string Jobdesc { get; set; }
        public double Hrcomplete { get; set; }
        public double Hrrate { get; set; }

        public Items()
        {
            Jobdesc = "Mow Yard";
            Hrcomplete = 1;
            Hrrate = 10.00;
            string[] Job = new string[5];
        }

        public Items(string jJobdesc, double jHrcomplete, double jHrrate)
        {
            Jobdesc = jJobdesc;
            Hrcomplete = jHrcomplete;
            Hrrate = jHrrate;
        }

        public double Fee()
        {
            return Hrcomplete * Hrrate;
        }

        public override string ToString()
        {
            return "Jobdesc" + Hrcomplete + Hrrate + Fee();   
        }
    }
}
