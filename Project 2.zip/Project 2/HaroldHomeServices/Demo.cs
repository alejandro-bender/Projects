﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HaroldHomeServices
{
    public partial class Demo : Form
    {
        public Demo()
        {
            InitializeComponent();
        }

        private void BtnReturnto_Click(object sender, EventArgs e)
        {
            Menu1 dForm = new Menu1();
            dForm.ShowDialog();

        }

        private void Demo_Load(object sender, EventArgs e)
        {
            foreach (var item in Menu1.jArray)
            {
                if (item == null)
                {

                    lblDemo.Text = "";

                    Job jobtest = new Job();
                    lblDemo.Text += jobtest.ToString();

                    jobtest = new Job("Mow Yard");
                    lblDemo.Text += jobtest.ToString();

                    jobtest = new Job("Mow yard", 2.5, 16.00);
                    lblDemo.Text += jobtest.ToString();

                    jobtest = new Job();
                    jobtest.Jobdesc = " ";
                    jobtest.Hrcomplete = 3;
                    jobtest.Hrcomplete = 10.00;
                    lblDemo.Text += "Job Description is: " + jobtest.Jobdesc + "\n"
                        + "Hours to complete to job is: " + jobtest.Hrcomplete + "\n"
                        + "The rate on the job is: " + jobtest.Hrrate + "\n"
                        + "The total is: " + jobtest.Fee() + "\n" +
                        "\n";
            
                    lblDemo.Text += jobtest.ToString();
                    lblDemo.Text += "\n";
                    

                }
            }
        }
    }
}
