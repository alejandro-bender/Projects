﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HaroldHomeServices
{
    public partial class InputData : Form
    {
        public InputData()
        {
            InitializeComponent();
        }

        private void Test_Load(object sender, EventArgs e)
       {
            btnCombine.Enabled = false;
            if (Menu1.jIndex > 4)
            {
                btnCombine.Enabled = true;
                lblCb.Text = "Ok now u can click";
            }

            Array.Sort(Menu1.jArray);
            foreach (var item in Menu1.jArray)
            {
                if (item != null)
                {
                    lblDisplay.Text += item.ToString();
                    lblDisplay.Text += "\n";
                    
                }
                
            }
        }           

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu1 dForm = new Menu1();
            dForm.ShowDialog();
        }

        private void btnCombine_Click(object sender, EventArgs e)
        {
            this.Hide();
            Combine dForm = new Combine();
            dForm.ShowDialog();
        }
    }
}
