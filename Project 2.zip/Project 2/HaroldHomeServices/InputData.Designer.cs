﻿namespace HaroldHomeServices
{
    partial class InputData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReturn = new System.Windows.Forms.Button();
            this.lblDisplay = new System.Windows.Forms.Label();
            this.btnCombine = new System.Windows.Forms.Button();
            this.lblCb = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(524, 288);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(94, 23);
            this.btnReturn.TabIndex = 0;
            this.btnReturn.Text = "Return to Menu";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // lblDisplay
            // 
            this.lblDisplay.AutoSize = true;
            this.lblDisplay.Location = new System.Drawing.Point(30, 57);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(0, 13);
            this.lblDisplay.TabIndex = 1;
            // 
            // btnCombine
            // 
            this.btnCombine.Location = new System.Drawing.Point(567, 52);
            this.btnCombine.Name = "btnCombine";
            this.btnCombine.Size = new System.Drawing.Size(113, 23);
            this.btnCombine.TabIndex = 7;
            this.btnCombine.Text = "Combine Jobs";
            this.btnCombine.UseVisualStyleBackColor = true;
            this.btnCombine.Click += new System.EventHandler(this.btnCombine_Click);
            // 
            // lblCb
            // 
            this.lblCb.AutoSize = true;
            this.lblCb.Location = new System.Drawing.Point(481, 24);
            this.lblCb.Name = "lblCb";
            this.lblCb.Size = new System.Drawing.Size(260, 13);
            this.lblCb.TabIndex = 8;
            this.lblCb.Text = "You must enter 5 jobs before you can click this button";
            // 
            // InputData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 386);
            this.Controls.Add(this.lblCb);
            this.Controls.Add(this.btnCombine);
            this.Controls.Add(this.lblDisplay);
            this.Controls.Add(this.btnReturn);
            this.Name = "InputData";
            this.Text = "Harold Home Services";
            this.Load += new System.EventHandler(this.Test_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.Button btnCombine;
        private System.Windows.Forms.Label lblCb;
    }
}