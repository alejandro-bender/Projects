﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HaroldHomeServices
{
    public partial class Form1 : Form
    {
      

        public Form1()
        {
            InitializeComponent();
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            if (Menu1.jIndex > Menu1.jArray.Length - 1)
            {
                MessageBox.Show("Maximum number of passengers exceeded");
            }
            else
            {
                //get each field and validate before instantiating
                Job j = new Job();

                if (String.IsNullOrEmpty(txtJobdesc.Text.Trim()))
                {
                    j.Jobdesc = "Mow yard";
                }
                else
                {
                    j.Jobdesc = txtJobdesc.Text;
                }

                if (String.IsNullOrEmpty(txtHrcomplete.Text.Trim()))
                {
                    j.Hrcomplete = 1;
                }
                else
                {
                    double complete;
                    bool a = Double.TryParse(txtHrcomplete.Text.Trim(), out complete);
                    if (a)
                    {
                        j.Hrcomplete = complete;
                    }
                    else
                    {
                        j.Hrcomplete = 1;
                    }
                }
                if (String.IsNullOrEmpty(txtHrrate.Text.Trim()))
                {
                        j.Hrrate = 10.00;
                }
                    else
                    {
                        double rate;
                        bool b = Double.TryParse(txtHrrate.Text.Trim(), out rate);
                        if (b)
                        {
                            j.Hrrate = rate;
                        }
                        else
                        {
                            j.Hrcomplete = 10.00;
                        }
                    }

                Menu1.jArray[Menu1.jIndex] = j;
                Menu1.jIndex++;
                j.Jobdesc = txtJobdesc.Text;
                j.Hrcomplete = Convert.ToDouble(txtHrcomplete.Text);
                j.Hrrate = Convert.ToDouble(txtHrrate.Text);
                
            }
            txtJobdesc.Clear();
            txtHrcomplete.Clear();
            txtHrrate.Clear();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            this.Hide();
            InputData dForm = new InputData();
            dForm.ShowDialog();
        }
    }
}
