﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DormStudents
{
    public partial class Display : Form
    {
        public Display()
        {
            InitializeComponent();
        }

        private void Display_Load(object sender, EventArgs e)
        {
            List<student> sortedstudent = new List<student>(Menu1.StudentList);
            sortedstudent.Sort();

            foreach (var item in sortedstudent)
            {
                if (item is DormStudent)
                {
                    DormStudent d = (DormStudent)item;
                    lblDisplay.Text += d.ToString();
                    lblDisplay.Text += "\n";
                }
                else
                if (item != null)
                {
                    lblDisplay.Text += item.ToString();
                    lblDisplay.Text += "\n";

                }

            }
        }

        private void btnstu_Click(object sender, EventArgs e)
        {
            this.Hide();
            Input dForm = new Input();
            dForm.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete dForm = new Delete();
            dForm.ShowDialog();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            this.Hide();
            Change dForm = new Change();
            dForm.ShowDialog();
        }

        private void btnPoints_Click(object sender, EventArgs e)
        {
            if (Menu1.StudentList.Count > 0)
            {
                AddGrade dForm = new AddGrade();
                dForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("You cant not click on this button until u have a student in the list");
            }
            
        }
    }
}
