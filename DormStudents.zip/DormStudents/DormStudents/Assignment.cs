﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DormStudents
{
    [Serializable]
    public class Assignment
    {
        public string AssignmentName { get; set; }
        public double AssignmentPoints { get; set; }
        public double AssignmentPointsPossible { get; set; }

        public Assignment()
        {
            AssignmentName = "C#";
            AssignmentPoints= 0;
            AssignmentPointsPossible = 0;
        }

        public Assignment(string Name, double points, double PointsPoss)
        {
            AssignmentName = Name;
            AssignmentPoints = points;
            AssignmentPointsPossible = PointsPoss;
        }
    }
}
