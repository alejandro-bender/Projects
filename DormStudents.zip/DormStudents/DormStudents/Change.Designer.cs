﻿namespace DormStudents
{
    partial class Change
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDis = new System.Windows.Forms.Button();
            this.meals = new System.Windows.Forms.GroupBox();
            this.rbBas = new System.Windows.Forms.RadioButton();
            this.rbMed = new System.Windows.Forms.RadioButton();
            this.rbHigh = new System.Windows.Forms.RadioButton();
            this.cbDorms = new System.Windows.Forms.GroupBox();
            this.rbTrust = new System.Windows.Forms.RadioButton();
            this.rbOak = new System.Windows.Forms.RadioButton();
            this.rbWap = new System.Windows.Forms.RadioButton();
            this.rbApp = new System.Windows.Forms.RadioButton();
            this.rbMah = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbYes = new System.Windows.Forms.RadioButton();
            this.rbNo = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.btnBkk = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblWhat = new System.Windows.Forms.Label();
            this.lblWhich = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSearch2 = new System.Windows.Forms.Button();
            this.meals.SuspendLayout();
            this.cbDorms.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDis
            // 
            this.btnDis.Location = new System.Drawing.Point(489, 133);
            this.btnDis.Name = "btnDis";
            this.btnDis.Size = new System.Drawing.Size(121, 23);
            this.btnDis.TabIndex = 47;
            this.btnDis.Text = "Display Students";
            this.btnDis.UseVisualStyleBackColor = true;
            this.btnDis.Click += new System.EventHandler(this.btnDis_Click);
            // 
            // meals
            // 
            this.meals.Controls.Add(this.rbBas);
            this.meals.Controls.Add(this.rbMed);
            this.meals.Controls.Add(this.rbHigh);
            this.meals.Location = new System.Drawing.Point(281, 232);
            this.meals.Name = "meals";
            this.meals.Size = new System.Drawing.Size(215, 41);
            this.meals.TabIndex = 46;
            this.meals.TabStop = false;
            // 
            // rbBas
            // 
            this.rbBas.AutoSize = true;
            this.rbBas.Location = new System.Drawing.Point(6, 19);
            this.rbBas.Name = "rbBas";
            this.rbBas.Size = new System.Drawing.Size(51, 17);
            this.rbBas.TabIndex = 14;
            this.rbBas.TabStop = true;
            this.rbBas.Text = "Basic";
            this.rbBas.UseVisualStyleBackColor = true;
            this.rbBas.CheckedChanged += new System.EventHandler(this.rbBas_CheckedChanged_1);
            // 
            // rbMed
            // 
            this.rbMed.AutoSize = true;
            this.rbMed.Location = new System.Drawing.Point(63, 19);
            this.rbMed.Name = "rbMed";
            this.rbMed.Size = new System.Drawing.Size(62, 17);
            this.rbMed.TabIndex = 15;
            this.rbMed.TabStop = true;
            this.rbMed.Text = "Meduim";
            this.rbMed.UseVisualStyleBackColor = true;
            this.rbMed.CheckedChanged += new System.EventHandler(this.rbMed_CheckedChanged);
            // 
            // rbHigh
            // 
            this.rbHigh.AutoSize = true;
            this.rbHigh.Location = new System.Drawing.Point(131, 19);
            this.rbHigh.Name = "rbHigh";
            this.rbHigh.Size = new System.Drawing.Size(47, 17);
            this.rbHigh.TabIndex = 16;
            this.rbHigh.TabStop = true;
            this.rbHigh.Text = "High";
            this.rbHigh.UseVisualStyleBackColor = true;
            this.rbHigh.CheckedChanged += new System.EventHandler(this.rbHigh_CheckedChanged);
            // 
            // cbDorms
            // 
            this.cbDorms.Controls.Add(this.rbTrust);
            this.cbDorms.Controls.Add(this.rbOak);
            this.cbDorms.Controls.Add(this.rbWap);
            this.cbDorms.Controls.Add(this.rbApp);
            this.cbDorms.Controls.Add(this.rbMah);
            this.cbDorms.Location = new System.Drawing.Point(58, 232);
            this.cbDorms.Name = "cbDorms";
            this.cbDorms.Size = new System.Drawing.Size(200, 100);
            this.cbDorms.TabIndex = 45;
            this.cbDorms.TabStop = false;
            // 
            // rbTrust
            // 
            this.rbTrust.AutoSize = true;
            this.rbTrust.Location = new System.Drawing.Point(6, 20);
            this.rbTrust.Name = "rbTrust";
            this.rbTrust.Size = new System.Drawing.Size(82, 17);
            this.rbTrust.TabIndex = 7;
            this.rbTrust.TabStop = true;
            this.rbTrust.Text = "Trustee Hall";
            this.rbTrust.UseVisualStyleBackColor = true;
            this.rbTrust.CheckedChanged += new System.EventHandler(this.rbTrust_CheckedChanged_1);
            // 
            // rbOak
            // 
            this.rbOak.AutoSize = true;
            this.rbOak.Location = new System.Drawing.Point(6, 43);
            this.rbOak.Name = "rbOak";
            this.rbOak.Size = new System.Drawing.Size(66, 17);
            this.rbOak.TabIndex = 8;
            this.rbOak.TabStop = true;
            this.rbOak.Text = "Oak Hall";
            this.rbOak.UseVisualStyleBackColor = true;
            this.rbOak.CheckedChanged += new System.EventHandler(this.rbOak_CheckedChanged);
            // 
            // rbWap
            // 
            this.rbWap.AutoSize = true;
            this.rbWap.Location = new System.Drawing.Point(6, 66);
            this.rbWap.Name = "rbWap";
            this.rbWap.Size = new System.Drawing.Size(64, 17);
            this.rbWap.TabIndex = 9;
            this.rbWap.TabStop = true;
            this.rbWap.Text = "Wapello";
            this.rbWap.UseVisualStyleBackColor = true;
            this.rbWap.CheckedChanged += new System.EventHandler(this.rbWap_CheckedChanged);
            // 
            // rbApp
            // 
            this.rbApp.AutoSize = true;
            this.rbApp.Location = new System.Drawing.Point(91, 20);
            this.rbApp.Name = "rbApp";
            this.rbApp.Size = new System.Drawing.Size(79, 17);
            this.rbApp.TabIndex = 10;
            this.rbApp.TabStop = true;
            this.rbApp.Text = "Appanoose";
            this.rbApp.UseVisualStyleBackColor = true;
            this.rbApp.CheckedChanged += new System.EventHandler(this.rbApp_CheckedChanged);
            // 
            // rbMah
            // 
            this.rbMah.AutoSize = true;
            this.rbMah.Location = new System.Drawing.Point(91, 43);
            this.rbMah.Name = "rbMah";
            this.rbMah.Size = new System.Drawing.Size(69, 17);
            this.rbMah.TabIndex = 11;
            this.rbMah.TabStop = true;
            this.rbMah.Text = "Mahaska";
            this.rbMah.UseVisualStyleBackColor = true;
            this.rbMah.CheckedChanged += new System.EventHandler(this.rbMah_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbYes);
            this.groupBox1.Controls.Add(this.rbNo);
            this.groupBox1.Location = new System.Drawing.Point(240, 146);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(128, 36);
            this.groupBox1.TabIndex = 44;
            this.groupBox1.TabStop = false;
            // 
            // rbYes
            // 
            this.rbYes.AutoSize = true;
            this.rbYes.Location = new System.Drawing.Point(6, 13);
            this.rbYes.Name = "rbYes";
            this.rbYes.Size = new System.Drawing.Size(43, 17);
            this.rbYes.TabIndex = 28;
            this.rbYes.TabStop = true;
            this.rbYes.Text = "Yes";
            this.rbYes.UseVisualStyleBackColor = true;
            this.rbYes.CheckedChanged += new System.EventHandler(this.rbYes_CheckedChanged_1);
            // 
            // rbNo
            // 
            this.rbNo.AutoSize = true;
            this.rbNo.Location = new System.Drawing.Point(72, 13);
            this.rbNo.Name = "rbNo";
            this.rbNo.Size = new System.Drawing.Size(39, 17);
            this.rbNo.TabIndex = 29;
            this.rbNo.TabStop = true;
            this.rbNo.Text = "No";
            this.rbNo.UseVisualStyleBackColor = true;
            this.rbNo.CheckedChanged += new System.EventHandler(this.rbNo_CheckedChanged_1);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Algerian", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(757, 36);
            this.label7.TabIndex = 43;
            this.label7.Text = "Students of Indain Hills Community College";
            // 
            // btnBkk
            // 
            this.btnBkk.Location = new System.Drawing.Point(489, 162);
            this.btnBkk.Name = "btnBkk";
            this.btnBkk.Size = new System.Drawing.Size(121, 23);
            this.btnBkk.TabIndex = 42;
            this.btnBkk.Text = "Back";
            this.btnBkk.UseVisualStyleBackColor = true;
            this.btnBkk.Click += new System.EventHandler(this.btnBkk_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(489, 102);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(121, 23);
            this.btnSave.TabIndex = 41;
            this.btnSave.Text = "Save student";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblWhat
            // 
            this.lblWhat.AutoSize = true;
            this.lblWhat.Location = new System.Drawing.Point(284, 202);
            this.lblWhat.Name = "lblWhat";
            this.lblWhat.Size = new System.Drawing.Size(0, 13);
            this.lblWhat.TabIndex = 40;
            // 
            // lblWhich
            // 
            this.lblWhich.AutoSize = true;
            this.lblWhich.Location = new System.Drawing.Point(55, 202);
            this.lblWhich.Name = "lblWhich";
            this.lblWhich.Size = new System.Drawing.Size(0, 13);
            this.lblWhich.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(185, 13);
            this.label3.TabIndex = 38;
            this.label3.Text = "Are you a student that live in the dorm";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 37;
            this.label2.Text = "Student ID Number:";
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(162, 86);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(142, 20);
            this.txtId.TabIndex = 36;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 35;
            this.label1.Text = "Student Name:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(139, 119);
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(165, 20);
            this.txtName.TabIndex = 34;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(55, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(348, 15);
            this.label4.TabIndex = 48;
            this.label4.Text = "You have to search for the student by thier id number";
            // 
            // btnSearch2
            // 
            this.btnSearch2.Location = new System.Drawing.Point(489, 73);
            this.btnSearch2.Name = "btnSearch2";
            this.btnSearch2.Size = new System.Drawing.Size(121, 23);
            this.btnSearch2.TabIndex = 49;
            this.btnSearch2.Text = "Search for Students";
            this.btnSearch2.UseVisualStyleBackColor = true;
            this.btnSearch2.Click += new System.EventHandler(this.btnSearch2_Click);
            // 
            // Change
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSearch2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnDis);
            this.Controls.Add(this.meals);
            this.Controls.Add(this.cbDorms);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnBkk);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblWhat);
            this.Controls.Add(this.lblWhich);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtName);
            this.Name = "Change";
            this.Text = "Change";
            this.Load += new System.EventHandler(this.Change_Load);
            this.meals.ResumeLayout(false);
            this.meals.PerformLayout();
            this.cbDorms.ResumeLayout(false);
            this.cbDorms.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDis;
        private System.Windows.Forms.GroupBox meals;
        private System.Windows.Forms.RadioButton rbBas;
        private System.Windows.Forms.RadioButton rbMed;
        private System.Windows.Forms.RadioButton rbHigh;
        private System.Windows.Forms.GroupBox cbDorms;
        private System.Windows.Forms.RadioButton rbTrust;
        private System.Windows.Forms.RadioButton rbOak;
        private System.Windows.Forms.RadioButton rbWap;
        private System.Windows.Forms.RadioButton rbApp;
        private System.Windows.Forms.RadioButton rbMah;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbYes;
        private System.Windows.Forms.RadioButton rbNo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnBkk;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblWhat;
        private System.Windows.Forms.Label lblWhich;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSearch2;
    }
}