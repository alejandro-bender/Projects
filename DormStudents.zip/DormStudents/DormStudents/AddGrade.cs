﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DormStudents
{
    public partial class AddGrade : Form
    {
        public AddGrade()
        {
            InitializeComponent();
        }

        private bool uStudent = false;
        private bool uDorm = false;
        private bool delete = false;

       

        private void btnDel_Click(object sender, EventArgs e)
        {
            lbStudents.Items.RemoveAt(lbStudents.SelectedIndex);
        }

        private void btnBac_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void btnAd_Click(object sender, EventArgs e)
        {
            Menu1.StudentList[lbStudents.SelectedIndex].Assign = new List<Assignment>();
            foreach (DataGridViewRow d in dgvGrades.Rows)
            {
                if (d.Cells[0].Value != null)
                {
                    string s = d.Cells[0].Value.ToString();
                    double a = Convert.ToDouble(d.Cells[1].Value);
                    double b = Convert.ToDouble(d.Cells[2].Value);
                    Assignment c = new Assignment(s, a, b);
                    Menu1.StudentList[lbStudents.SelectedIndex].Assign.Add(c);
                }
            }
        }

        private void AddGrade_Load(object sender, EventArgs e)
        {
            foreach (var item in Menu1.StudentList)
            {
                lbStudents.Items.Add(item.StudentName);
            }

        }

        private void lbStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = 0;
            dgvGrades.Rows.Clear();

            if (lbStudents.SelectedIndex >= 0)
            {
                foreach (var item in Menu1.StudentList[lbStudents.SelectedIndex].Assign)
                {
                    dgvGrades.Rows.Add();
                    dgvGrades.Rows[i].Cells[0].Value = item.AssignmentName;
                    dgvGrades.Rows[i].Cells[1].Value = item.AssignmentPoints.ToString("F2");
                    dgvGrades.Rows[i].Cells[2].Value = item.AssignmentPointsPossible.ToString("F2");
                    i++;
                }
            }
        }
    }
}
    

