﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DormStudents
{
    public partial class Change : Form
    {
        public Change()
        {
            InitializeComponent();
        }


        public string tempDorm;
        public string tempMeals;
        private bool uStudent = false;
        private bool uDorm = false;

        private void btnSearch2_Click(object sender, EventArgs e)
        {
            try
            {
                txtName.Text = String.Empty;
                var a = Menu1.StudentList.Find(s => s.StudentId == Convert.ToInt32(txtId.Text));

                if (a != null)
                {
                    txtName.Text = a.StudentName;
                    uDorm = false;
                    uStudent = true;
                }
                else if (a != null)
                {
                    txtName.Text = a.StudentName;
                    uStudent = false;
                    uDorm = true;
                }
            }
            catch
            {
                MessageBox.Show("Enter Student ID.");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            student s = new student();
            DormStudent m = new DormStudent();

            if (String.IsNullOrEmpty(txtName.Text.Trim()))
            {
                MessageBox.Show("This is not a correct name. Please try again");
                return;
            }
            else
            {
                s.StudentName = txtName.Text;
            }

            try
            {
                if (txtId.Text.Length != 7)
                {
                    MessageBox.Show("The id needs to be 7 digits long");
                }
                s.StudentId = Convert.ToInt32(txtId.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("This is not correct number. Please try again");
                return;
            }

            Menu1.StudentList.RemoveAll(i => i.StudentId == Convert.ToInt32(txtId.Text));

            if (rbYes.Checked)
            {
                DormStudent t = new DormStudent(s.StudentName, s.StudentId, tempDorm, tempMeals);
                Menu1.StudentList.Add(t);
            }
            else
            {
                student st = new student(s.StudentName, s.StudentId);
                Menu1.StudentList.Add(st);
            }
            txtId.Clear();
            txtName.Clear();
        }

        private void btnDis_Click(object sender, EventArgs e)
        {
            this.Hide();
            Display dForm = new Display();
            dForm.ShowDialog();
        }

        private void btnBkk_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu1 dForm = new Menu1();
            dForm.ShowDialog();
        }

        private void Change_Load(object sender, EventArgs e)
        {
            rbTrust.Enabled = false;
            rbOak.Enabled = false;
            rbWap.Enabled = false;
            rbApp.Enabled = false;
            rbMah.Enabled = false;
            rbBas.Enabled = false;
            rbMed.Enabled = false;
            rbHigh.Enabled = false;
        }

        private void rbYes_CheckedChanged_1(object sender, EventArgs e)
        {
            lblWhich.Text = "Which dorm do you live in";
            lblWhat.Text = "What meal plan do you have";
            rbTrust.Enabled = true;
            rbOak.Enabled = true;
            rbWap.Enabled = true;
            rbApp.Enabled = true;
            rbMah.Enabled = true;
            rbBas.Enabled = true;
            rbMed.Enabled = true;
            rbHigh.Enabled = true;
        }

        private void rbNo_CheckedChanged_1(object sender, EventArgs e)
        {
            lblWhich.Text = "You are finish here :)";
            lblWhat.Text = " ";
            rbTrust.Enabled = false;
            rbOak.Enabled = false;
            rbWap.Enabled = false;
            rbApp.Enabled = false;
            rbMah.Enabled = false;
            rbBas.Enabled = false;
            rbMed.Enabled = false;
            rbHigh.Enabled = false;
        }

        private void rbTrust_CheckedChanged_1(object sender, EventArgs e)
        {
            if (rbTrust.Checked == true)
            {
                tempDorm = "Trustee Hall";
                return;
            }    
        }

        private void rbOak_CheckedChanged(object sender, EventArgs e)
        {
            if (rbOak.Checked == true)
            {
                tempDorm = "Oak Hall";
                return;
            }
        }

        private void rbWap_CheckedChanged(object sender, EventArgs e)
        {
            if (rbWap.Checked == true)
            {
                tempDorm = "Wapello Hall";
                return;
            }
        }

        private void rbApp_CheckedChanged(object sender, EventArgs e)
        {
            if (rbApp.Checked == true)
            {
                tempDorm = "Appanoose Hall";
                return;
            }
        }

        private void rbMah_CheckedChanged(object sender, EventArgs e)
        {
            if (rbMah.Checked == true)
            {
                tempDorm = "Mahaska Hall";
                return;
            }
        }

        private void rbBas_CheckedChanged_1(object sender, EventArgs e)
        {
            if (rbBas.Checked == true)
            {
                tempMeals = "Basic meal plan";
                return;
            } 
        }

        private void rbMed_CheckedChanged(object sender, EventArgs e)
        {
            if (rbMed.Checked == true)
            {
                tempMeals = "Meduim meal plan";
                return;
            }
        }

        private void rbHigh_CheckedChanged(object sender, EventArgs e)
        {
            if (rbHigh.Checked == true)
            {
                tempMeals = "High meal plan";
                return;
            }
        }
    }
}
