﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace DormStudents
{
    public partial class Menu1 : Form
    {
        public static List<student> StudentList = new List<student>();
        public Menu1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            
            Display dForm = new Display();
            dForm.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Input dForm = new Input();
            dForm.ShowDialog();
        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you wish write these Students to the file",
                "Write To File", MessageBoxButtons.YesNo, MessageBoxIcon.Hand,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                try
                {
                    FileStream outFile = new FileStream("StudentList.ser",
                         FileMode.Create, FileAccess.Write);
                    BinaryFormatter bf = new BinaryFormatter();

                    foreach (var item in Menu1.StudentList)
                    {
                        bf.Serialize(outFile, item);
                    }
                    outFile.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error writing list to file " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("New items not written");
            }
            this.Close();
        }

        private void Menu1_Load(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists("StudentList.ser"))
                {
                    FileStream inFile = new FileStream("StudentList.ser",
                        FileMode.Open, FileAccess.Read);
                    BinaryFormatter bFormatter = new BinaryFormatter();

                    //copy invoices from the file to the invoiceList
                    while (inFile.Position < inFile.Length)
                    {
                        object obj = bFormatter.Deserialize(inFile);
                        if (obj.GetType() == typeof(student))
                        {
                            Menu1.StudentList.Add((student)obj);
                        }
                        else
                        {
                            Menu1.StudentList.Add((DormStudent)obj);
                        }
                    }
                    inFile.Close();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening file, program terminating" + ex.Message);
            }
        }
    }
}
