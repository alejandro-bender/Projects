﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DormStudents
{
    [Serializable]
    public class student : IComparable
    {
        public string StudentName { get; set; }
        public int StudentId { get; set; }
        public List<Assignment> Assign { get; set; }
        


        public student()
        {
            StudentName = "John Smith";
            StudentId = 0000000;
            Assign = new List<Assignment>();
        }


        public student(string stuname, int idnumber)
        {
            StudentName = stuname;
            StudentId = idnumber;
            Assign = new List<Assignment>();
        }

        public override string ToString()
        {
            return "The Student name is: " + StudentName + "\n" +
                "The Student id is: " + StudentId + "\n";
        }

        int IComparable.CompareTo(object o)
        {
            int returnVal;
            student temp = (student)o;
            if (this.StudentId > temp.StudentId)
                returnVal = 1;
            else
                if (this.StudentId < temp.StudentId)
                returnVal = -1;
            else
                returnVal = 0;
            return returnVal;
        }
    }
}
