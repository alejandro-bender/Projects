﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DormStudents
{
    public partial class Delete : Form
    {
        public Delete()
        {
            InitializeComponent();
        }

        private bool uStudent = false;
        private bool uDorm = false;
        private bool delete = false;

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                txtName.Text = String.Empty;
                var a = Menu1.StudentList.Find(s => s.StudentId == Convert.ToInt32(txtId.Text));

                if (a != null)
                {
                    txtName.Text = a.StudentName;
                    uDorm = false;
                    uStudent = true;
                }
                else if (a != null)
                {
                    txtName.Text = a.StudentName;
                    uStudent = false;
                    uDorm = true;
                }
            }
            catch
            {
                MessageBox.Show("Enter Student ID.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (uDorm)
                {
                    Menu1.StudentList.RemoveAll(s => s.StudentId == Convert.ToInt32(txtId.Text));
                    txtName.Text = String.Empty;
                    delete = true;
                }

                if (uStudent)
                {
                    Menu1.StudentList.RemoveAll(s => s.StudentId == Convert.ToInt32(txtId.Text));
                    txtName.Text = String.Empty;
                    delete = true;
                }

                if (delete)
                {
                    MessageBox.Show("Student deleted.");
                }
                else
                {
                    MessageBox.Show("Student not in the list.");
                }

            }
            catch
            {
                MessageBox.Show("Enter Student ID.");
            }
        }

        private void btnBkk_Click(object sender, EventArgs e)
        {
            this.Hide();
            Menu1 dForm = new Menu1();
            dForm.ShowDialog();
        }
    }
}
