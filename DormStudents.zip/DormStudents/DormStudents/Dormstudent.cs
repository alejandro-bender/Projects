﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DormStudents
{
    [Serializable]

    public class DormStudent : student
    {
        public string Dorm { get; set; }
        public string MealPlan { get; set; }



        public DormStudent() : base()
        {
            Dorm = "Oak";
            MealPlan = "High";
        }


        public DormStudent(string stuname, int idnumber, string dorname, string meal) : base(stuname, idnumber)
        {
            Dorm = dorname;
            MealPlan = meal;
        }

        

        public override string ToString() 
        {
            return base.ToString() + "The Dorm name is: " + Dorm + "\n" +
                                      "Your meal plan is: " + MealPlan + "\n";
        }

    }
}
