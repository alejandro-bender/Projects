﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Athlete
{
    class BaseballPlayer : Athlete
    {
        private int hits { get; set; }
        private int bats { get; set; }
        private int rbi { get; set; }
        private int homeruns { get; set; }
        private double innings { get; set; }


        public BaseballPlayer() : base()
        {
            hits = 10;
            bats = 300;
            rbi = 10;
            homeruns = 10;
            innings = 9;

        }

        //overloaded constructor - must call base overloaded constructor first
        public BaseballPlayer(int h, int b, int r, int home, double i) :
            base(num, name, rate, bal)
        {
            hits = h;
            bats = b;
            rbi = r;
            homeruns = home;
            innings = i;
        }

        public double CalcsAvg()
        {
            double avg;
             avg = hits / bats;
        }

        public override string ToString()
        {
            return base.ToString() + Format(),hits + bats + rbi + homeruns + innings;
        }
    }
}
