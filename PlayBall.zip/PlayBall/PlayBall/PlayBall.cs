using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlayBall
{
    class Program
    {
        static short[,] players = new short[12, 2];
        static void Main()
        {
            string[] Names;
            Init(out Names);
            Menu(ref Names, ref players);
        }

        private static void Init(out string[] Names)
        {
            FileStream fsNames = new FileStream("Names.dat", FileMode.Open, FileAccess.Read);
            StreamReader srNames = new StreamReader(fsNames);
            Names = new string[12];
            string record = srNames.ReadLine();
            int r = 0;

            while (record != null)
            {
                Names[r++] = record;
                record = srNames.ReadLine();
            }

        }

        public static void Menu(ref string[] Names, ref short[,] players)
        {

            Console.Clear();
            Console.WriteLine("Enter in 1 to enter data \nEnter in 2 for Summary \nEnter in 3 to exit");
            string inputString1 = Console.ReadLine();

            if (inputString1 == "1")
            {
                GetData(ref Names, ref players);
                Summary(ref Names, ref players);
            }
            else
                if (inputString1 == "2")
            {
                Summary(ref Names, ref players);
            }
            else
                if (inputString1 == "3")
            {
                Environment.Exit(0);
            }


        }

        //this where i am getting all my data 
        private static void GetData(ref string[] Names, ref short[,] players)
        {
            Console.Clear();
            String again = "Y";
            string inputString;
            int player = 0;
            int i = 0;
            

            while (again == "Y")
            {
                do
                {
                    try
                    {
                        Console.WriteLine("Enter a number between 1 and 12: ");
                        inputString = Console.ReadLine().Trim();
                        player = Convert.ToInt16(inputString);
                        if (player < 0 || player > 12)
                        {
                            Console.WriteLine("Players must be from 1 thru 12 ");
                        }
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Players must be from 1 thru 12, please try again:");
                        player = -1;
                    }
                } while (player < 0 || player > 12);



                //prompting for hits
                do
                {
                    try
                    {
                        Console.WriteLine("Enter the amount of hits the player had: ");
                        inputString = Console.ReadLine().Trim();
                        players[i, 0] = Convert.ToInt16(inputString);
                        if (players[i, 0] < 0)
                        {
                            Console.WriteLine("Hits must be numeric");
                        }
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Hits must be numeric");
                    } 
                } while (players[i, 0] < 0);
                players[player-1, 0] += players[i, 0];


                // prompting for bat
                do
                {
                    try
                    {
                        Console.WriteLine("Enter the amount of bats the player had: ");
                        inputString = Console.ReadLine().Trim();
                        players[i, 1] = Convert.ToInt16(inputString);
                        if (players[i, 1] < 0)
                        {
                            Console.WriteLine("Bats must be numeric");
                        }
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Bats must be numeric, please try again ");
                        players[i, 1] = -1;
                    }
                } while (players[i, 1] < 0);
                players[player-1, 1] += players[i, 1];

                Console.WriteLine("Do you want to enter another player stats? (Y/N)");
                again = Console.ReadLine().ToUpper();
            } 
            Menu(ref Names, ref players);
        }
    
        
        // my summary and calcs together.
        public static void Summary(ref string[] Names, ref short[,] players)
        {
            for (int i = 0; i < 12; i++)
            {
                double average = 0.000;
                try
                {
                    
                    if (players[i, 0] ==0)
                    {
                        average = 0.000;
                    }
                    else
                    {
                        average = (double)players[i, 0] / players[i, 1];
                    }
                }
                catch (Exception)
                {

                    average = 0.000;
                }
                string Output = String.Format("{0,-18}|{1,-5}|{2,-5}|{3,-10}",Names[i], players[i, 0],players[i, 1],average.ToString("F3"));
                Console.WriteLine(Output);
            }
            Console.WriteLine("Do you want to go back to the Main Menu Y or N");        
                string input = Console.ReadLine().ToUpper();
                if (input == "Y")
                {
                    Menu( ref Names, ref players);
    
                }
                else
                {
                    Environment.Exit(0);
                }
            
        }
    }
}
